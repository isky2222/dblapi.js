# Gem Exchange Discord Bots

- [The Gem Exchange](http://thegemexchange.net/)
- [Discord Server](https://discord.gg/7QqTw83)

# Feature Requests

Feature requests are welcome! The easiest way for me to get to them is through this repo's [issues page](https://github.com/juan0tron/gem-exchange-bot/issues).

# Adding a bot to your server

https://discordapp.com/api/oauth2/authorize?client_id=XXXXXXXXXXXXXXX&scope=bot&permissions=1

# To Do / Idea Pipeline

- Command for showing server rules
